from tkinter import *
from Tool.Calaolater import create_calculator
from Tool.Note import create_Note
from Tool.ToDoList import creat_ToDo
from Tool.Bomodoro import create_Timer
from Sorce.Global import *
import webbrowser
import os
import sys
Main_form = Tk()

#-----------------------------------------| Image Lode && OS SYS |------------------------------------------------!#
def resource_path(relative_path): # --> TO Lode Image in Setup File
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


calcolater_IMG = PhotoImage(file=resource_path("Image/Button Icon/calcolatr-Button-ico.png"))
ToDO_IMG = PhotoImage(file=resource_path("Image/Button Icon/todolest-Button-Ico.png"))
Pomodoro_IMG = PhotoImage(file=resource_path("Image/Button Icon/Bomodoro-Button-Ico.png"))
Twiter_LOGO = PhotoImage(file=resource_path("Image/T_LoGo.png"))
Instgram_LOGO = PhotoImage(file=resource_path("Image/I_LoGo.png"))
Google_LOGO = PhotoImage(file=resource_path("Image/Gmail_loGo.png"))
Note_IMG = PhotoImage(file=resource_path("Image/Button Icon/notebook-Button-Ico.png"))
chatGPT_IMG = PhotoImage(file=resource_path("Image/Button Icon/chatgpt-Button-Ico.png"))
Sarch_Icone = PhotoImage(file=resource_path("Image/Sarch-Icon.png"))
Google_lio = PhotoImage(file=resource_path("Image/Google-icon-UB.png"))


#-----------------------------------------| Main Form Option  |-----------------------------------------------------!#
Main_form.geometry("1024x650+180+20") #? --> Hight and Wight of Windos
Main_form.resizable(False, False) #? --> Hide The Maxmain Button
Main_form.title("JKobeo") #? --> Titel of Program
Main_form.config(bg="#D3D3D3",relief="flat") #? --> Option 

leb_Left = Label(Main_form, bg="#607D8B", fg="#F5F5DC", font=("arial", 12))
leb_Left.place(x=0, y=0, width=200, height=700)

#-----------------------------------------| Import and Open the Def |------------------------------------------------!#

# Forms
def open_note(): #? -- Enable Note Form 
    create_Note()
def open_calculator(): #? -- Enable Calculator Form 
    create_calculator()
def open_Todo(): #? -- Enable Todo Lest Form 
    creat_ToDo()
def open_Timer(): #? Enable Timer/Bomodoro Form 
    create_Timer()

# Website
def open_ChatGPT(): #? Enable chatGPT WEB
    webbrowser.open("https://chatgpt.com")
def Open_insta(): #? Open Instgram WEB
    webbrowser.open("https://www.instagram.com/mwwaajeddd/") 
def Open_Twiter(): #? Open Twiter WEB
    webbrowser.open("https://x.com/scorfar58100") 
def Open_Google(): #? Open Googlr WEB 
    webbrowser.open("https://mail.google.com")
def click_JK_Logo():
    webbrowser.open("https://jkopeo.odoo.com")


#-----------------------------------------| All thinks abuot Home Button|-----------------------------------------------!#
def click_Home():

    # Global Import From Sores.Global.py
    global calolat_But, Note_Button, ToDO_Button, Pomodoro_Button, chatGPT_Button, suport_panal, Instgram_Button, Instgram_Text, Google_Button, Titer_Button, Google_Text, Titer_Text, Serch_button,Sarch_entre,Google_Icon,Home_Banal

    # To Desable Buttons
    if suport_panal: suport_panal.place_forget()
    if Titer_Button: Titer_Button.place_forget()
    if Titer_Text: Titer_Text.place_forget()
    if Instgram_Button: Instgram_Button.place_forget()
    if Instgram_Text: Instgram_Text.place_forget()
    if Google_Button: Google_Button.place_forget()
    if Google_Text: Google_Text.place_forget()
    if Serch_button: Serch_button.place_forget()
    if Sarch_entre: Sarch_entre.place_forget()
    if Google_Icon: Google_Icon.place_forget()

    
    # Calculator Button
    calolat_But = Button(Main_form, image=calcolater_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_calculator)
    calolat_But.place(x=845, y=70, width=170, height=170)

    # Note Button
    Note_Button = Button(Main_form, image=Note_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_note)
    Note_Button.place(x=685, y=70, width=175, height=170)

    # To Do List Button
    ToDO_Button = Button(Main_form, image=ToDO_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_Todo)
    ToDO_Button.place(x=525, y=70, width=170, height=170)

    # Chat GPT Button
    chatGPT_Button = Button(Main_form, image=chatGPT_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_ChatGPT)
    chatGPT_Button.place(x=365, y=70, width=170, height=170)

    # Pomodoro Timer Button
    Pomodoro_Button = Button(Main_form, image=Pomodoro_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_Timer)
    Pomodoro_Button.place(x=205, y=70, width=170, height=170)


#-----------------------------------------| All thinks abuot About Us Button|----------------------------------------------!#

def click_AbuotUs():

    # Global Import From Sores.Global.py   
    global calolat_But, Note_Button, ToDO_Button, Pomodoro_Button, chatGPT_Button, suport_panal, Titer_Text, Instgram_Button, Instgram_Text, Google_Button, Google_Text, Titer_Button,Serch_button,Sarch_entre,Google_Icon,Home_Banal

    # desable Button
    if calolat_But: calolat_But.place_forget()
    if Note_Button: Note_Button.place_forget()
    if ToDO_Button: ToDO_Button.place_forget()
    if Pomodoro_Button: Pomodoro_Button.place_forget()
    if chatGPT_Button: chatGPT_Button.place_forget()
    if Serch_button: Serch_button.place_forget()
    if Sarch_entre: Sarch_entre.place_forget()
    if Google_Icon: Google_Icon.place_forget()


    # Instgram Button
    Instgram_Button = Button(Main_form, image=Instgram_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_insta)
    Instgram_Button.place(x=300, y=110, width=90, height=90)
    Instgram_Text = Label(Main_form, text=" OR  --> https://www.instagram.com/mwwaajeddd/")
    Instgram_Text.place(x=380, y=145)

    # Twiter Button
    Titer_Button = Button(Main_form, image=Twiter_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_Twiter)
    Titer_Button.place(x=300, y=185, width=90, height=90)
    Titer_Text = Label(Main_form, text=" OR  --> https://x.com/scorfar58100")
    Titer_Text.place(x=380, y=220)

    # Google Button
    Google_Button = Button(Main_form, image=Google_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_Google)
    Google_Button.place(x=300, y=260, width=90, height=90)
    Google_Text = Label(Main_form, text=" OR  --> mareano15s@gmail.com")
    Google_Text.place(x=380, y=295)

    # Panel Support Such Media
    suport_panal = Label(Main_form, text="Suport", bg="gray", fg="#F5F5DC", font=("arial", 12))
    suport_panal.place(x=300, y=100, width=600, height=20)


#-----------------------------------------| All thinks abuot Sarch Button|-----------------------------------------------!#
def click_Sarch():

    # Global Import From Sores.Global.py
    global calolat_But, Note_Button, ToDO_Button, Pomodoro_Button, chatGPT_Button, suport_panal, Titer_Text, Instgram_Button, Instgram_Text, Google_Button, Google_Text, Titer_Button,Serch_button,Sarch_entre,Google_Icon,Home_Banal

    # TO desable Buttons
    if calolat_But: calolat_But.place_forget()
    if Note_Button: Note_Button.place_forget()
    if ToDO_Button: ToDO_Button.place_forget()
    if Pomodoro_Button: Pomodoro_Button.place_forget()
    if chatGPT_Button: chatGPT_Button.place_forget()
    if suport_panal: suport_panal.place_forget()
    if Titer_Button: Titer_Button.place_forget()
    if Titer_Text: Titer_Text.place_forget()
    if Instgram_Button: Instgram_Button.place_forget()
    if Instgram_Text: Instgram_Text.place_forget()
    if Google_Button: Google_Button.place_forget()
    if Google_Text: Google_Text.place_forget()

    # sarch on Google
    def Serch_Gogle():
        query = Sarch_entre.get()
        search_url = f"https://www.google.com/search?q={query}"
        webbrowser.open(search_url)

    # Google banal
    Google_Icon = Button(Main_form,image=Google_lio,relief="flat",bd=0,bg="#D3D3D3")
    Google_Icon.place(x=470,y=130)

    # Sarch Batton 
    Serch_button = Button(Main_form, image=Sarch_Icone,relief="flat",bd=0,command=Serch_Gogle)
    Serch_button.place(x=320, y=295)

    # Serch Bar
    Sarch_entre = Entry(Main_form, width=60,relief="flat",font=("arial", 13))
    Sarch_entre.place(x=370,y=300,height=30)


#-----------------------------------------| All Button in main Form|-----------------------------------------------!#

# Home Button
Home_Im = PhotoImage(file="Image/ButtonTX/Home.png")
But1 = Button(Main_form,image=Home_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_Home,bg="#DAD9D6")
But1.place(x=30, y=140, width=130, height=40)

# Sarch Button
search_Im = PhotoImage(file="Image/ButtonTX/Sarche.png")
But2 = Button(Main_form,image=search_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_Sarch,bg="#DAD9D6")
But2.place(x=30, y=210, width=130, height=35)

# About Us Button
Support_Im = PhotoImage(file="Image/ButtonTX/Support.png")
But3 = Button(Main_form,image=Support_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_AbuotUs)
But3.place(x=30, y=275, width=130, height=35.5)

# Jk Oprion
Jk_icon = PhotoImage(file="Image/ButtonTX/Jk.png")
but4 = Button(Main_form,image=Jk_icon,bd=0,bg="#DAD9D6",activebackground="#ADD8E6",command=click_JK_Logo)
but4.place(x=52,y=15,width=80,height=90)


click_Home()
Main_form.mainloop()
