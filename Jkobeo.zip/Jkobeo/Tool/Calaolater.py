import tkinter as tk

def create_calculator():
    def calculate(operation):
        try:
            num1 = float(entry1.get())
            num2 = float(entry2.get())
            
            if operation == "+":
                result = num1 + num2
            elif operation == "-":
                result = num1 - num2
            elif operation == "*":
                result = num1 * num2
            elif operation == "/":
                if num2 != 0:
                    result = num1 / num2
                else:
                    result = "Error: Division by Zero"
            else:
                result = "Error: Invalid Operation"
            
            result_var.set(result)
        except ValueError:
            result_var.set("Error: Invalid Input")
    
    calc_window = tk.Toplevel()
    calc_window.title("Calculator - Jk")
    calc_window.geometry("300x300")
    #calc_window.iconbitmap("Docemnt/1_6.ico")

    entry1 = tk.Entry(calc_window, font=("Arial", 14), fg="#000000",relief="groove")
    entry1.pack(pady=10, padx=20)

    entry2 = tk.Entry(calc_window, font=("Arial", 14), fg="#000000",relief="groove")
    entry2.pack(pady=10, padx=20)

    operations_frame = tk.Frame(calc_window, bg="#D3D3D3")
    operations_frame.pack(pady=10)

    operations = ["+", "-", "*", "/"]
    buttons = []
    
    for op in operations:
        button = tk.Button(operations_frame, text=op, command=lambda op=op: calculate(op), fg="#000000", font=("Arial", 12), width=4, height=2,relief="flat")
        buttons.append(button)
    
    for i, button in enumerate(buttons):
        button.grid(row=0, column=i, padx=5)

    result_var = tk.StringVar()
    result_entry = tk.Entry(calc_window, textvariable=result_var, font=("Arial", 14), bg="gray", fg="#000000", state="readonly")
    result_entry.pack(pady=10, padx=20)
