from tkinter import *

def creat_ToDo():
    
    ToDO_Windos = Tk()
    ToDO_Windos.geometry("400x500")
    #ToDO_Windos.iconbitmap("Docemnt/1_6.ico")
    ToDO_Windos.title("To Do Lest - Jk")

    def add_task():
        task = task_Entry.get()
        if task:
            task_list.insert(0, task)
            task_Entry.delete(0, END)
            save_tasks()
        else:
            print("ERROR: No task entered")
            
    def remove_task():
        selected = task_list.curselection()
        if selected:
            task_list.delete(selected[0])
            save_tasks()
        else:
            print("ERROR: No task selected")
    
    def save_tasks():
        with open("tasks.txt", "w") as f:
            tasks = task_list.get(0, END)
            for task in tasks:
                f.write(task + "\n")
    
    def load_tasks():
        try:
            with open("tasks.txt", "r") as f:
                tasks = f.readlines()
                for task in tasks:
                    task_list.insert(0, task.strip())
        except FileNotFoundError:
            print("ERROR: File not found")


    Add_button = Button(ToDO_Windos, command=add_task, bg="gray", text="Add", activebackground="#ADD8E6", relief="flat", bd=0.1)
    Add_button.place(x=50, y=100, width=130, height=30)

    Remove_button = Button(ToDO_Windos, command=remove_task, bg="gray", text="Remove", activebackground="#ADD8E6", relief="flat", bd=0.1)
    Remove_button.place(x=220, y=100, width=130, height=30)

    task_Entry = Entry(ToDO_Windos,relief="flat",bg="gray")
    task_Entry.place(x=40, y=40, width=320, height=30)

    task_list = Listbox(ToDO_Windos, width=49, height=18,relief="flat",bg="gray")
    task_list.place(x=50, y=150)

    load_tasks()
