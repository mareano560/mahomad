from tkinter import *
from tkinter import filedialog

def create_Note():
    # Create the main note window
    note_Windos = Tk()
    note_Windos.title("Note - JK")
    note_Windos.geometry("600x480")
    note_Windos.config(bg="#D3D3D3")
    #note_Windos.iconbitmap("Docemnt/1_6.ico")

    # Create a Text Box for note input
    Text_Boxe = Text(note_Windos, bg="gray", width=73, height=26.5, fg="#F5F5DC")
    Text_Boxe.place(x=6, y=40)

    # Function to save the content of the note
    def save_file():
        fill_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if fill_path:
            text_to_save = Text_Boxe.get(1.0, END).rstrip()
            with open(fill_path, "w", encoding="utf-8") as file:
                file.write(text_to_save)

    # Create a Save button
    Save_button = Button(note_Windos, bg="gray", text="Save", activebackground="#ADD8E6", relief="flat", bd=0.1, command=save_file)
    Save_button.place(x=10, y=10)

