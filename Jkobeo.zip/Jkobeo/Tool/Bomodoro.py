from tkinter import *

Work_Timer = 25 * 60
Short_brake = 5 * 60
Long_brake = 15 * 60

def create_Timer():
    class PomodoroTimer:
        def __init__(self):
            self.Timer_Window = Tk()
            self.Timer_Window.geometry("300x200")
            self.Timer_Window.title("Pomodoro Timer")

            self.start_Button = Button(self.Timer_Window, text="Start", command=self.start_timer)
            self.start_Button.pack(pady=5)

            self.stop_Button = Button(self.Timer_Window, text="Stop", command=self.stop_timer, state=DISABLED)
            self.stop_Button.pack(pady=5)

            self.timer_label = Label(self.Timer_Window, text=self.format_time(Work_Timer), font=("Arial", 24))
            self.timer_label.pack(pady=20)

            self.work_time = Work_Timer
            self.break_time = Short_brake
            self.is_running = False
            self.is_work_timer = True
            self.pomodoros_completed = 0

            self.Timer_Window.mainloop()

        def format_time(self, seconds):
            minutes = seconds // 60
            seconds = seconds % 60
            return f"{minutes:02d}:{seconds:02d}"

        def start_timer(self):
            self.start_Button.config(state=DISABLED)
            self.stop_Button.config(state=NORMAL)
            self.is_running = True
            self.update_timer()

        def stop_timer(self):
            self.start_Button.config(state=NORMAL)
            self.stop_Button.config(state=DISABLED)
            self.is_running = False

        def update_timer(self):
            if self.is_running:
                if self.is_work_timer:
                    self.work_time -= 1
                    self.timer_label.config(text=self.format_time(self.work_time))
                    if self.work_time == 0:
                        self.is_work_timer = False
                        self.pomodoros_completed += 1
                        self.break_time = Long_brake if self.pomodoros_completed % 4 == 0 else Short_brake
                        print("Great Job!")
                else:
                    self.break_time -= 1
                    self.timer_label.config(text=self.format_time(self.break_time))
                    if self.break_time == 0:
                        self.is_work_timer = True
                        self.work_time = Work_Timer

                self.Timer_Window.after(1000, self.update_timer)

    PomodoroTimer()

