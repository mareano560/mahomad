from tkinter import *

# the Globals
Serch_button = None
Sarch_entre = None
suport_panal = None
Instgram_Button = None
Instgram_Text = None
Titer_Button = None
Titer_Text = None
Google_Button = None
Google_Text = None
calolat_But = None
Note_Button = None
ToDO_Button = None
Google_Icon = None
Pomodoro_Button = None
chatGPT_Button = None
Home_Banal = None